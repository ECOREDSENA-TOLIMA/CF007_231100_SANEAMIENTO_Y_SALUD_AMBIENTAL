function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ak7NSyNC4d":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

